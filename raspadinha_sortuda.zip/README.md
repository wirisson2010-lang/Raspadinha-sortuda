# Raspadinha Sortuda — demonstração

Projeto estático para celular e computador. Não envolve apostas, dinheiro ou prêmios reais.

## Como testar
Abra `index.html` no navegador. Para publicar, envie os três arquivos (`index.html`, `style.css`, `app.js`) para um repositório GitHub e habilite GitHub Pages.

## Arquivos
- `index.html`: estrutura
- `style.css`: visual responsivo
- `app.js`: lógica de raspar e seleção de símbolo
